<?php
/**
 * Plugin Name: MMC - FAQ
 * Description: Integration of React Vite app with WordPress
 * Version: 1.0.0
 * Author: Sravanthi Sinha
 * Text Domain: mmc-faq
 * License: GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 */

if (!defined('ABSPATH')) {
    exit;
}

class MMC_FAQ_App {
    private static $instance = null;
    private $plugin_dir;
    private $plugin_url;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->plugin_dir = plugin_dir_path(__FILE__);
        $this->plugin_url = plugin_dir_url(__FILE__);
        
        add_shortcode('mmc_faq', array($this, 'render_react_app'));
        add_action('wp_enqueue_scripts', array($this, 'register_assets'), 1);
        add_action('wp_enqueue_scripts', array($this, 'enqueue_assets'), 2);
        add_action('wp_head', array($this, 'add_critical_css'), 1);
        add_action('wp_footer', array($this, 'inline_init_script'), 1);
        
        register_activation_hook(__FILE__, array($this, 'activate'));
    }
    
    public function add_critical_css() {
        global $post;
        if (!is_a($post, 'WP_Post') || !has_shortcode($post->post_content, 'mmc_faq')) {
            return;
        }
        ?>
        <style id="mmc-faq-critical">
        .wp-react-app-container {
            position: relative;
            min-height: 100px;
            opacity: 1;
        }
        .react-loading-placeholder {
            display: block;
            width: 100%;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        .faq-skeleton {
            width: 100%;
        }
        .skeleton-title, .skeleton-item {
            background: linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%);
            background-size: 200% 100%;
            animation: mmcSkeleton 1.5s infinite;
            border-radius: 4px;
        }
        .skeleton-title {
            height: 32px;
            margin-bottom: 20px;
        }
        .skeleton-item {
            height: 60px;
            margin-bottom: 10px;
        }
        @keyframes mmcSkeleton {
            0% { background-position: 200% 0; }
            100% { background-position: -200% 0; }
        }
        </style>
        <?php
    }
    
    public function inline_init_script() {
        global $post;
        if (!is_a($post, 'WP_Post') || !has_shortcode($post->post_content, 'mmc_faq')) {
            return;
        }
        ?>
        <script>
        (function() {
            var init = function() {
                var containers = document.querySelectorAll('.wp-react-app-container');
                containers.forEach(function(container) {
                    var placeholder = container.querySelector('.react-loading-placeholder');
                    if (placeholder) {
                        placeholder.style.display = 'none';
                    }
                });
            };
            
            if (document.readyState === 'complete' || document.readyState === 'interactive') {
                init();
            } else {
                document.addEventListener('DOMContentLoaded', init);
            }
        })();
        </script>
        <?php
    }
    
    public function activate() {
        if (version_compare(PHP_VERSION, '7.0', '<')) {
            deactivate_plugins(plugin_basename(__FILE__));
            wp_die('MMC FAQ requires PHP 7.0 or higher.');
        }
        flush_rewrite_rules();
    }
    
    public function register_assets() {
        if (!file_exists($this->plugin_dir . 'dist/manifest.json')) {
            return;
        }
        
        $manifest = json_decode(file_get_contents($this->plugin_dir . 'dist/manifest.json'), true);
        if (!$manifest) {
            return;
        }
        
        foreach ($manifest as $file => $details) {
            if (isset($details['isEntry']) && $details['isEntry']) {
                $js_path = $details['file'];
                $js_url = $this->plugin_url . 'dist/' . $js_path;
                $version = filemtime($this->plugin_dir . 'dist/' . $js_path);
                
                wp_register_script('mmc-faq-main', $js_url, array(), $version, true);
                wp_script_add_data('mmc-faq-main', 'defer', true);
                
                if (isset($details['css'])) {
                    foreach ($details['css'] as $css_file) {
                        wp_register_style('mmc-faq-css', $this->plugin_url . 'dist/' . $css_file, array(), $version);
                    }
                }
                
                wp_localize_script('mmc-faq-main', 'mmcFaqData', array(
                    'ajaxUrl' => admin_url('admin-ajax.php'),
                    'nonce' => wp_create_nonce('mmc_faq_nonce'),
                    'pluginUrl' => $this->plugin_url,
                ));
                
                break;
            }
        }
    }
    
    public function enqueue_assets() {
        global $post;
        if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'mmc_faq')) {
            wp_enqueue_script('mmc-faq-main');
            wp_enqueue_style('mmc-faq-css');
        }
    }
    
    public function render_react_app($atts) {
        $atts = shortcode_atts(array(
            'id' => 'mmc-faq-' . uniqid(),
            'class' => '',
            'category' => '',
        ), $atts, 'mmc_faq');
        
        $data_attrs = '';
        foreach ($atts as $key => $value) {
            if ($key !== 'id' && $key !== 'class') {
                $data_attrs .= sprintf(' data-%s="%s"', esc_attr($key), esc_attr($value));
            }
        }
        
        $skeleton_html = '
            <div class="react-loading-placeholder">
                <div class="faq-skeleton">
                    <div class="skeleton-title"></div>
                    <div class="skeleton-item"></div>
                    <div class="skeleton-item"></div>
                    <div class="skeleton-item"></div>
                </div>
            </div>
        ';
        
        return sprintf(
            '<div id="%s" class="wp-react-app-container %s"%s>%s</div>',
            esc_attr($atts['id']),
            esc_attr($atts['class']),
            $data_attrs,
            $skeleton_html
        );
    }
}

function mmc_faq_plugin() {
    return MMC_FAQ_App::get_instance();
}

mmc_faq_plugin();